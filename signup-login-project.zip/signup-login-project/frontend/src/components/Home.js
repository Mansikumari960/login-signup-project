import React, { useEffect, useState } from "react";

export default function Home() {
  const [profile, setProfile] = useState(null);
  const [msg, setMsg] = useState("Loading...");

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      setMsg("Welcome! Please explore our app 🚀");
      return;
    }

    fetch("http://localhost:5000/api/profile", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          setProfile(data.user);
        } else {
          setMsg("Session expired, please login again.");
        }
      })
      .catch(() => setMsg("Something went wrong, please try again later."));
  }, []);

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      {profile ? (
        <h2>Welcome back, {profile.name}! 🎉</h2>
      ) : (
        <h2>{msg}</h2>
      )}
      <p style={{ color: "gray" }}>
        This is your home page. You can navigate to other sections using the menu.
      </p>
    </div>
  );
}