import React from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Navbar() {
  const navigate = useNavigate();
  const token = localStorage.getItem("token");

  function logout() {
    localStorage.removeItem("token");
    navigate("/login");
  }

  return (
    <nav style={{ padding: "10px 16px", background: "#eee", display: "flex", justifyContent: "space-between" }}>
      <div>
        <Link to="/" style={{ marginRight: 12, textDecoration: "none" }}>Home</Link>
        <Link to="/signup" style={{ marginRight: 12, textDecoration: "none" }}>Signup</Link>
        <Link to="/login" style={{ textDecoration: "none" }}>Login</Link>
      </div>
      {token && <button onClick={logout}>Logout</button>}
    </nav>
  );
}